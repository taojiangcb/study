<template>
  <div id="app">
    <!-- <img src="./assets/logo.png">
    <router-view/>-->
    <m-header></m-header>
  </div>
</template>

<script>
import MHeader from "components/m-header/m-header";
export default {
  name: "App",
  components: {
    MHeader
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
