const path = require('path');

module.exports =  {
  SSR_BUILD:path.resolve(__dirname,'../dist'),
  SSR_CLIENT:path.resolve(__dirname,'../public'),
} 