
import React from 'react';
export class Home extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        <div> this is ssr11  1231112312sssssdfasdfassssssssssss  </div>
        <button onClick={(e) => {
          alert('点一下1112sss22试试');
        }}>12sss3</button>
        <h1>111===1111=sss1ssssdddfff111ssssssss</h1>
      </div>
    )
  }
}