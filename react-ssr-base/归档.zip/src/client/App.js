
import React from 'react';
import ReactDom from 'react-dom';
import { Home } from '../containers/home/Home.jsx';


let HomeElement = React.createElement(Home);

ReactDom.hydrate(HomeElement, document.getElementById("root"));
