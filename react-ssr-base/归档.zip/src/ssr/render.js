
import {Home} from '../containers/home/Home.jsx';
import { renderToString } from 'react-dom/server';
import React from 'react';

const render = (req) => {
  let content = renderToString(React.createElement(Home));
  return content;
}

export {render};