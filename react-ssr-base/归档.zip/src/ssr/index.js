import express from 'express';
import { render } from './render';

let template = `
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
</head>
<body>
  <div id="root"><!--content--></div>
  <script src="index.js"></script>
</body>
</html>
`;


var app = express();
app.use(express.static('public'));

app.get('*', (req, res) => {
  let content = render(req);
  // let html = template.replace('<!--content-->', content);
  let html = template.replace('<!--content-->', content);
  res.send(html);

})

app.listen(3000, () => { console.log('ssr server start....'); })


// export default app;